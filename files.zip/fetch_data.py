"""
fetch_data.py

Pulls channel + video-level data from the YouTube Data API v3 and lands it
in a local SQLite database (raw, minimally transformed — that happens in
transform.py / the dashboard).

Usage:
    # pass channel IDs directly:
    python fetch_data.py UCxxxxxxxx UCyyyyyyyy

    # or, for bulk additions, put one channel ID per line in a text file
    # (blank lines and lines starting with # are ignored) and run:
    python fetch_data.py --file channels.txt

Finding a channel ID:
    Go to the channel's page -> "..." or About -> Share -> Copy channel ID
    (it starts with UC...). Or use https://commentpicker.com/youtube-channel-id.php
"""

import os
import sys
import sqlite3
from datetime import datetime, timezone

from googleapiclient.discovery import build
from dotenv import load_dotenv

load_dotenv()

API_KEY = os.getenv("YOUTUBE_API_KEY")
DB_PATH = "youtube_data.db"


def load_channel_ids_from_file(path: str) -> list:
    """Read one channel ID per line, skipping blanks and #-comments."""
    if not os.path.exists(path):
        sys.exit(f"Channel ID file not found: {path}")

    ids = []
    with open(path) as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith("#"):
                ids.append(line)
    return ids


def get_client():
    if not API_KEY:
        sys.exit("Missing YOUTUBE_API_KEY. Copy .env.example to .env and add your key.")
    return build("youtube", "v3", developerKey=API_KEY)


def init_db(conn):
    conn.executescript(
        """
        CREATE TABLE IF NOT EXISTS channels (
            channel_id TEXT PRIMARY KEY,
            title TEXT,
            subscriber_count INTEGER,
            view_count INTEGER,
            video_count INTEGER,
            fetched_at TEXT
        );

        CREATE TABLE IF NOT EXISTS videos (
            video_id TEXT PRIMARY KEY,
            channel_id TEXT,
            title TEXT,
            published_at TEXT,
            duration_seconds INTEGER,
            is_short INTEGER,
            view_count INTEGER,
            like_count INTEGER,
            comment_count INTEGER,
            fetched_at TEXT
        );
        """
    )
    conn.commit()


def parse_iso8601_duration(duration: str) -> int:
    """Convert YouTube's ISO 8601 duration (e.g. 'PT1M30S') to seconds."""
    import re

    match = re.match(
        r"PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?", duration
    )
    if not match:
        return 0
    hours, minutes, seconds = (int(g) if g else 0 for g in match.groups())
    return hours * 3600 + minutes * 60 + seconds


def fetch_channel(youtube, channel_id: str) -> dict:
    resp = youtube.channels().list(
        part="snippet,statistics,contentDetails", id=channel_id
    ).execute()

    if not resp["items"]:
        raise ValueError(f"No channel found for ID {channel_id}")

    item = resp["items"][0]
    return {
        "channel_id": channel_id,
        "title": item["snippet"]["title"],
        "subscriber_count": int(item["statistics"].get("subscriberCount", 0)),
        "view_count": int(item["statistics"].get("viewCount", 0)),
        "video_count": int(item["statistics"].get("videoCount", 0)),
        "uploads_playlist_id": item["contentDetails"]["relatedPlaylists"]["uploads"],
    }


def fetch_video_ids_from_playlist(youtube, playlist_id: str, max_videos: int = 50) -> list:
    """Grab the most recent `max_videos` video IDs from a channel's uploads playlist."""
    video_ids = []
    next_page_token = None

    while len(video_ids) < max_videos:
        resp = youtube.playlistItems().list(
            part="contentDetails",
            playlistId=playlist_id,
            maxResults=min(50, max_videos - len(video_ids)),
            pageToken=next_page_token,
        ).execute()

        video_ids.extend(item["contentDetails"]["videoId"] for item in resp["items"])
        next_page_token = resp.get("nextPageToken")
        if not next_page_token:
            break

    return video_ids


def fetch_video_details(youtube, video_ids: list) -> list:
    """Batch-fetch stats + duration for up to 50 video IDs at a time."""
    videos = []
    for i in range(0, len(video_ids), 50):
        batch = video_ids[i : i + 50]
        resp = youtube.videos().list(
            part="snippet,statistics,contentDetails", id=",".join(batch)
        ).execute()

        for item in resp["items"]:
            duration_seconds = parse_iso8601_duration(
                item["contentDetails"]["duration"]
            )
            videos.append(
                {
                    "video_id": item["id"],
                    "channel_id": item["snippet"]["channelId"],
                    "title": item["snippet"]["title"],
                    "published_at": item["snippet"]["publishedAt"],
                    "duration_seconds": duration_seconds,
                    "is_short": 1 if duration_seconds <= 60 else 0,
                    "view_count": int(item["statistics"].get("viewCount", 0)),
                    "like_count": int(item["statistics"].get("likeCount", 0)),
                    "comment_count": int(item["statistics"].get("commentCount", 0)),
                }
            )
    return videos


def main():
    if len(sys.argv) < 2:
        sys.exit(
            "Usage:\n"
            "  python fetch_data.py <channel_id_1> [channel_id_2 ...]\n"
            "  python fetch_data.py --file channels.txt"
        )

    if sys.argv[1] == "--file":
        if len(sys.argv) < 3:
            sys.exit("Usage: python fetch_data.py --file channels.txt")
        channel_ids = load_channel_ids_from_file(sys.argv[2])
        if not channel_ids:
            sys.exit(f"No channel IDs found in {sys.argv[2]}")
    else:
        channel_ids = sys.argv[1:]

    print(f"Fetching {len(channel_ids)} channel(s)...\n")
    youtube = get_client()
    conn = sqlite3.connect(DB_PATH)
    init_db(conn)

    now = datetime.now(timezone.utc).isoformat()

    for channel_id in channel_ids:
        print(f"Fetching channel {channel_id}...")
        channel = fetch_channel(youtube, channel_id)

        conn.execute(
            """INSERT OR REPLACE INTO channels
               (channel_id, title, subscriber_count, view_count, video_count, fetched_at)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (
                channel["channel_id"],
                channel["title"],
                channel["subscriber_count"],
                channel["view_count"],
                channel["video_count"],
                now,
            ),
        )

        print(f"  Fetching recent video IDs...")
        video_ids = fetch_video_ids_from_playlist(youtube, channel["uploads_playlist_id"])

        print(f"  Fetching details for {len(video_ids)} videos...")
        videos = fetch_video_details(youtube, video_ids)

        for v in videos:
            conn.execute(
                """INSERT OR REPLACE INTO videos
                   (video_id, channel_id, title, published_at, duration_seconds,
                    is_short, view_count, like_count, comment_count, fetched_at)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    v["video_id"],
                    v["channel_id"],
                    v["title"],
                    v["published_at"],
                    v["duration_seconds"],
                    v["is_short"],
                    v["view_count"],
                    v["like_count"],
                    v["comment_count"],
                    now,
                ),
            )

        conn.commit()
        print(f"  Done: {channel['title']} ({len(videos)} videos saved)\n")

    conn.close()
    print(f"All data saved to {DB_PATH}")


if __name__ == "__main__":
    main()
